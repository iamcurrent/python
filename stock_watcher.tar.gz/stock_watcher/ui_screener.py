# -*- coding: utf-8 -*-
"""
ui_screener.py —— "股票排行"选股界面。

功能：
    - 按量比 / 换手率 / 涨跌幅 三种维度排序筛选前 100 名
    - 展示列：排名、代码、名称、现价、涨跌幅、换手率、量比、所属板块
    - 全市场扫描在后台线程执行，结果缓存，三榜秒切
"""

import threading
import time

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QBrush, QFont
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QHeaderView, QLabel, QPushButton, QComboBox, QGroupBox, QTextEdit,
)

import screener

RED = QColor(230, 60, 60)
GREEN = QColor(30, 160, 90)


class ScreenerPanel(QWidget):
    """股票排行面板。"""

    METRICS = [
        ("lb", "按量比"),
        ("hsl", "按换手率"),
        ("zdf", "按涨跌幅"),
        ("score", "按综合评分"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.market_data = []      # 全市场快照
        self.sector_map = {}
        self.current_metric = "lb"
        self.refreshing = False

        self._build_ui()
        # 首次自动刷新
        self.refresh()

    # ---------- UI ----------

    def _build_ui(self):
        root = QVBoxLayout(self)

        bar = QHBoxLayout()
        bar.addWidget(QLabel("排行维度:"))
        self.metric_combo = QComboBox()
        for key, label in self.METRICS:
            self.metric_combo.addItem(label, key)
        self.metric_combo.currentIndexChanged.connect(self._on_metric_change)
        bar.addWidget(self.metric_combo)

        bar.addSpacing(12)
        self.status_label = QLabel("就绪")
        bar.addWidget(self.status_label)
        bar.addStretch(1)

        refresh_btn = QPushButton("刷新数据")
        refresh_btn.clicked.connect(self.refresh)
        bar.addWidget(refresh_btn)
        root.addLayout(bar)

        # 排名表（11列；综合评分模式显示"评分"与"近5日"，其余模式隐藏）
        self.table = QTableWidget(0, 11)
        self.table.setHorizontalHeaderLabels(
            ["排名", "评分", "代码", "名称", "现价", "涨跌幅",
             "换手率", "量比", "近5日", "技术形态", "所属板块"])
        # 默认隐藏 评分 和 近5日 两列（综合评分模式时显示）
        self.table.setColumnHidden(1, True)
        self.table.setColumnHidden(8, True)
        self.table.setColumnHidden(9, True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        for i, w in enumerate([44, 52, 64, 96, 70, 76, 70, 60, 66, 66, 70]):
            header.setSectionResizeMode(i, QHeaderView.Fixed if i < 10 else QHeaderView.Stretch)
            self.table.setColumnWidth(i, w)
        root.addWidget(self.table, 1)

        tip = QLabel("全市场扫描约需 2-3 秒，结果自动缓存，切换维度即时刷新；"
                     "综合评分综合考量成交额、量比、换手率、近期表现与技术形态"
                     "（由 5/10/20 日涨跌幅结构近似均线趋势）；"
                     "双击某行可查看该股精确的技术指标分")
        tip.setStyleSheet("color:#888;font-size:11px;")
        root.addWidget(tip)

    # ---------- 数据 ----------

    def refresh(self):
        if self.refreshing:
            return
        self.refreshing = True
        self.status_label.setText("正在扫描全市场...")
        self.table.setRowCount(0)
        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        try:
            market = screener.scan_market()
            sector = screener._load_sector_map()
            if not sector:
                try:
                    sector = screener.build_sector_map()
                    screener._save_sector_map(sector)
                except Exception:
                    sector = {}
            self.market_data = market
            self.sector_map = sector
        except Exception as e:
            self._post_status(f"扫描失败: {e}")
            self.refreshing = False
            return
        self._post_status(f"已加载 {len(market)} 只股票，"
                          f"板块覆盖 {len(sector)} 只，耗时 就绪")
        # 用 QTimer 确保回到 UI 线程刷新表格
        QTimer.singleShot(0, self._render_table)

    def _render_table(self):
        self.refreshing = False
        metric = self.current_metric
        if metric == "score":
            top = screener.top_by_score(self.market_data, 100, self.sector_map)
        else:
            top = screener.top_by_metric(self.market_data, metric, 100,
                                         self.sector_map)
        is_score = (metric == "score")
        self.table.setColumnHidden(1, not is_score)   # 评分列
        self.table.setColumnHidden(8, not is_score)   # 近5日列
        self.table.setColumnHidden(9, not is_score)   # 技术形态列
        self._fill_table(top)
        self.status_label.setText(
            f"共 {len(self.market_data)} 只，{self.metric_combo.currentText()}"
            f" 取前 {len(top)} 名")

    def _fill_table(self, records):
        self.table.setRowCount(len(records))
        for i, r in enumerate(records, 1):
            up = r["change_pct"] >= 0
            color = RED if up else GREEN
            has_score = "score" in r
            d5 = r.get("zdf_d5")
            trend = r.get("trend_structure")
            cells = [
                str(i),
                f"{r['score']:.1f}" if has_score else "",
                r["code"],
                r["name"],
                f"{r['price']:.2f}" if r["price"] else "--",
                f"{r['change_pct']:+.2f}%",
                f"{r['turnover_rate']:.2f}%",
                f"{r['volume_ratio']:.2f}",
                (f"{d5:+.2f}%" if d5 is not None else "--"),
                (f"{trend:.0f}" if (has_score and trend is not None) else ""),
                r["sector"],
            ]
            # 数字列着色
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignCenter)
                if col in (4, 5):       # 现价、涨跌幅用涨跌色
                    item.setForeground(QBrush(color))
                elif col == 1:          # 评分
                    item.setForeground(QBrush(QColor(255, 240, 120)))
                    item.setFont(QFont("Sans Serif", 9, QFont.Bold))
                elif col == 6:          # 换手率
                    item.setForeground(QBrush(QColor(90, 170, 255)))
                elif col == 7:          # 量比
                    item.setForeground(QBrush(QColor(255, 200, 60)))
                elif col == 8:          # 近5日
                    item.setForeground(QBrush(RED if (d5 or 0) >= 0 else GREEN))
                elif col == 9:          # 技术形态分（多头橙红/空头墨绿）
                    if trend is not None:
                        item.setForeground(QBrush(
                            RED if trend >= 60 else
                            (QColor(255, 200, 60) if trend >= 40 else GREEN)))
                self.table.setItem(i - 1, col, item)

    # ---------- 交互 ----------

    def _on_metric_change(self, index):
        self.current_metric = self.metric_combo.itemData(index)
        if self.market_data:
            self._render_table()

    def _post_status(self, msg):
        QTimer.singleShot(0, lambda: self.status_label.setText(msg))
