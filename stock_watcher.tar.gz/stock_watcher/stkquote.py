# -*- coding: utf-8 -*-
"""
stkquote.py —— A股实时行情数据抓取模块（基于腾讯股票行情接口，免费、无需 token）

数据来源：https://qt.gtimg.cn/q=sh600519,sz000001,...
返回格式：字段用 "~" 分隔，具体含义见 parse_quote()。

用法：
    from stkquote import fetch_quotes
    quotes = fetch_quotes(["sh600519", "sz000001"])   # 返回 dict: 代码 -> dict
"""

import time
import urllib.request

QUOTE_URL = "https://qt.gtimg.cn/q={}"

# 支持的证券市场前缀
MARKET_PREFIX = ("sh", "sz")

# 每次请求最多查询的股票数量（腾讯接口有上限，分批查询）
BATCH_SIZE = 50

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://finance.qq.com/",
}


def normalize_code(code: str) -> str:
    """将各种形式的股票代码规范化为 'sh/sz + 6位数字'。"""
    code = code.strip().lower()
    if code.startswith(MARKET_PREFIX):
        return code
    # 判断数字部分
    digits = "".join(ch for ch in code if ch.isdigit())
    if not digits:
        raise ValueError(f"无法识别股票代码: {code}")
    digits = digits.zfill(6)  # 补足 6 位
    # 根据规则推断市场：
    #   6xxxxx / 9xxxxx -> 沪市 sh；000/001/002/003/300/301 -> 深市 sz
    if digits.startswith(("6", "9")) or digits.startswith(("5",)):
        return "sh" + digits
    return "sz" + digits


def fetch_raw(codes: list) -> str:
    """批量抓取原始数据。codes 为规范化后的列表，如 ['sh600519']。"""
    symbols = ",".join(codes)
    url = QUOTE_URL.format(symbols)
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.read().decode("gbk", errors="ignore")


def parse_quote(line: str) -> dict:
    """解析腾讯接口返回的一行数据，转成结构化 dict。"""
    # 去掉 "v_sh600519=" 前缀和结尾分号
    if "=" not in line:
        return {}
    payload = line.split("=", 1)[1].strip().strip(';"')
    fields = payload.split("~")

    def _f(i, default=""):
        return fields[i] if i < len(fields) and fields[i] else default

    try:
        price = float(_f(3, 0))
        prev_close = float(_f(4, 0))
        open_price = float(_f(5, 0))
        change = float(_f(31, 0))
        change_pct = float(_f(32, 0))
        high = float(_f(33, 0))
        low = float(_f(34, 0))
        volume = float(_f(36, 0))        # 成交量（手）
        amount = float(_f(37, 0))        # 成交额（万元）
        turnover_rate = float(_f(38, 0)) # 换手率（%）
        volume_ratio = float(_f(49, 0))  # 量比
    except ValueError:
        price = prev_close = open_price = change = change_pct = 0.0
        high = low = volume = amount = 0.0
        turnover_rate = volume_ratio = 0.0

    quote = {
        "code": _f(2),                  # 股票代码（如 600519）
        "name": _f(1),                  # 股票名称（如 贵州茅台）
        "price": price,                 # 当前价
        "prev_close": prev_close,       # 昨收
        "open": open_price,             # 今开
        "high": high,                   # 最高
        "low": low,                     # 最低
        "change": change,               # 涨跌额
        "change_pct": change_pct,       # 涨跌幅（%）
        "volume": volume,               # 成交量（手）
        "amount": amount,               # 成交额（万元）
        "turnover_rate": turnover_rate, # 换手率（%）
        "volume_ratio": volume_ratio,   # 量比
        "time": _f(30),                 # 行情时间戳，如 20260908161435
    }
    return quote


def fetch_quotes(codes: list) -> dict:
    """抓取并解析一组股票的实时行情。

    参数：codes —— 规范化代码列表（如 ['sh600519', 'sz000001']）
    返回：dict { "sh600519": {quote}, ... }
    """
    result = {}
    norm_codes = [normalize_code(c) for c in codes]
    # 分批请求
    for i in range(0, len(norm_codes), BATCH_SIZE):
        batch = norm_codes[i:i + BATCH_SIZE]
        try:
            raw = fetch_raw(batch)
        except Exception as e:
            # 单批失败不致命，记录日志，返回空
            print(f"[stkquote] 批量获取失败 {batch}: {e}")
            time.sleep(1)
            continue
        for line in raw.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            quote = parse_quote(line)
            if quote and quote["code"]:
                result[quote["code"]] = quote
    return result


if __name__ == "__main__":
    # 简单自测
    test = ["sh600519", "sz000001", "sz300750", "sh601318", "sz002594"]
    quotes = fetch_quotes(test)
    for c, q in quotes.items():
        print(f"{q['code']} {q['name']} 现价={q['price']} 涨跌={q['change']:+.2f} "
              f"({q['change_pct']:+.2f}%) 量={q['volume']} 额={q['amount']}万")
