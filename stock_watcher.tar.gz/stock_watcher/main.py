#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main.py —— A股实时盯盘助手 入口脚本。

运行：
    python3 main.py

功能：
    - 自选股实时行情盯盘（每 5 秒自动刷新，可调）
    - 涨跌阈值报警、放量异动、技术指标（RSI）信号报警
    - K 线图 + 均线 + MACD 可视化
    - 技术指标面板（MA / MACD / RSI / KDJ / 量比）

依赖：仅 PyQt5（如未安装：pip3 install PyQt5）
数据源：腾讯股票行情接口（免费，无需 token）
"""

import sys


def main():
    # 在导入 PyQt5 前设置即席环境变量，避免高 DPI 模糊（可选）
    try:
        from PyQt5.QtCore import Qt
        Qt.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    except Exception:
        pass

    from PyQt5.QtWidgets import QApplication
    from ui_main import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName("A股实时盯盘助手")
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
