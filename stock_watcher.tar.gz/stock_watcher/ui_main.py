# -*- coding: utf-8 -*-
"""
ui_main.py —— 主窗口：自选股列表 + 实时行情 + K线图 + 技术指标 + 报警通知。

使用 PyQt5，通过 QTimer 定时轮询腾讯行情接口实现"实时盯盘"。
"""

import json
import os
import time
import threading

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt5.QtGui import QColor, QFont, QBrush
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QTableWidget, QTableWidgetItem, QHeaderView, QLabel, QPushButton,
    QLineEdit, QComboBox, QMessageBox, QGroupBox, QGridLayout,
    QApplication, QSpinBox, QDoubleSpinBox, QTextEdit, QCheckBox,
    QTabWidget,
)

from stkquote import fetch_quotes, normalize_code
from kline import fetch_kline
from minute import fetch_minute
from indicators import summarize, ma, macd, technical_score
from alerts import AlertEngine, send_desktop_notification
from ui_kline import ChartWidget
from ui_screener import ScreenerPanel

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

RED = QColor(230, 60, 60)      # 涨
GREEN = QColor(30, 160, 90)    # 跌


class WorkerBridge(QObject):
    """跨线程信号桥：把后台线程的计算结果安全地投递回 UI 线程。"""
    detail_ready = pyqtSignal(str, list, dict, dict, dict)  # symbol, klines, ma, macd, indicators
    minute_ready = pyqtSignal(str, dict)                    # symbol, minute_data
    alert_ready = pyqtSignal(str, str)                      # message, level


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("A股实时盯盘助手")
        self.resize(1180, 760)

        # 自选股（规范代码列表，如 sh600519）
        self.watchlist = self._load_config()

        # 最近一次行情缓存：{代码: quote}
        self.last_quotes = {}
        # 指标缓存：{代码: summarize dict}
        self.indicator_cache = {}
        # 分时数据缓存：{symbol: minute dict}
        self.minute_cache = {}
        # K线数据缓存：{symbol: (klines, ma, macd)}，用于切换图表模式时快速重绘
        self.kline_cache = {}

        # 报警引擎
        self.alert_engine = AlertEngine(notifier=self._on_alert)

        # 跨线程桥
        self.bridge = WorkerBridge()
        self.bridge.detail_ready.connect(self.apply_detail)
        self.bridge.minute_ready.connect(self.apply_minute)
        self.bridge.alert_ready.connect(self.append_log)

        self._build_ui()
        self._apply_default_rules()

        # 定时刷新（默认 5 秒）
        self.refresh_interval = 5
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(self.refresh_interval * 1000)

        # 首次刷新 & 预拉K线
        self.refresh()
        self._preload_klines()

        self.statusBar().showMessage("就绪 - 每 5 秒自动刷新")

    # ================= 配置存取 =================

    def _load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return data.get("watchlist", [])
            except Exception:
                pass
        return ["sh600519", "sz300750"]

    def _save_config(self):
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump({"watchlist": self.watchlist}, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _apply_default_rules(self):
        for code in self.watchlist:
            self.alert_engine.set_rules(code, [
                ("change_pct", {"up": 5.0, "down": -5.0}),
                ("volume", {}),
                ("rsi", {"overbought": 70, "oversold": 30}),
            ])

    # ================= UI 构建 =================

    def _build_ui(self):
        central = QWidget()
        root = QVBoxLayout(central)

        # ---- 顶部工具栏 ----
        top = QHBoxLayout()
        self.input = QLineEdit()
        self.input.setPlaceholderText("输入股票代码后回车添加，如 600519 / 301236 / sz000001")
        self.input.returnPressed.connect(self.add_stock)
        top.addWidget(self.input, 2)
        add_btn = QPushButton("添加")
        add_btn.clicked.connect(self.add_stock)
        top.addWidget(add_btn)
        remove_btn = QPushButton("删除选中")
        remove_btn.clicked.connect(self.remove_selected)
        top.addWidget(remove_btn)

        top.addSpacing(12)
        top.addWidget(QLabel("刷新间隔(秒)"))
        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(3, 120)
        self.interval_spin.setValue(5)
        self.interval_spin.valueChanged.connect(
            lambda v: (self.timer.setInterval(v * 1000),
                       self.statusBar().showMessage(f"刷新间隔设为 {v} 秒")))
        top.addWidget(self.interval_spin)

        self.notify_cb = QCheckBox("桌面通知")
        self.notify_cb.setChecked(True)
        top.addWidget(self.notify_cb)

        refresh_btn = QPushButton("立即刷新")
        refresh_btn.clicked.connect(self.refresh)
        top.addWidget(refresh_btn)
        root.addLayout(top)

        # ---- 主分割区域 ----
        splitter = QSplitter(Qt.Horizontal)

        # 左：自选股列表
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["代码", "名称", "现价", "涨跌幅", "涨跌", "成交量(手)"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        header = self.table.horizontalHeader()
        for i, w in enumerate([78, 90, 70, 70, 70, 90]):
            header.setSectionResizeMode(i, QHeaderView.Fixed)
            self.table.setColumnWidth(i, w)
        header.setSectionResizeMode(0, QHeaderView.Interactive)
        self.table.itemSelectionChanged.connect(self._on_select)
        self.table.doubleClicked.connect(self._on_select)
        left_layout.addWidget(self.table)

        # 提示
        tip = QLabel("双击某行查看该股的 K 线与技术指标；\n红色=上涨，绿色=下跌")
        tip.setStyleSheet("color:#888;font-size:11px;")
        left_layout.addWidget(tip)
        splitter.addWidget(left_panel)

        # 右侧面板
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)

        # 选中股标题
        self.selected_title = QLabel("请选择股票查看详情")
        self.selected_title.setStyleSheet("font-size:16px;font-weight:bold;color:#eee;")
        right_layout.addWidget(self.selected_title)

        # 指标概览与K线
        gk = QGroupBox("技术指标与行情")
        gk_layout = QGridLayout(gk)
        self.indicators_labels = {}
        ind_names = [
            ("tech_score", "技术形态分"), ("tech_state", "形态状态"),
            ("ma5", "五日均线"), ("ma10", "十日均线"), ("ma20", "二十日均线"),
            ("dif", "离差值"), ("dea", "信号线"), ("macd", "柱状值"),
            ("rsi6", "六日强弱"), ("rsi12", "十二日强弱"), ("rsi24", "二十四日强弱"),
            ("kdj_k", "随机K值"), ("kdj_d", "随机D值"), ("kdj_j", "随机J值"),
            ("volume_ratio", "量比"), ("turnover_rate", "换手率"),
        ]
        for idx, (key, name) in enumerate(ind_names):
            r, c = divmod(idx, 2)
            if not key:
                continue
            lab = QLabel(name)
            lab.setStyleSheet("color:#888;")
            val = QLabel("--")
            val.setTextInteractionFlags(Qt.TextSelectableByMouse)
            gk_layout.addWidget(lab, r, c * 2)
            gk_layout.addWidget(val, r, c * 2 + 1)
            self.indicators_labels[key] = val
        right_layout.addWidget(gk)

        # 图表模式切换 + 图表
        chart_bar = QHBoxLayout()
        chart_bar.addWidget(QLabel("图表类型:"))
        self.chart_mode = QComboBox()
        self.chart_mode.addItem("分时图", "minute")
        self.chart_mode.addItem("K线图", "kline")
        self.chart_mode.currentIndexChanged.connect(self._on_chart_mode)
        chart_bar.addWidget(self.chart_mode)
        chart_bar.addStretch(1)
        right_layout.addLayout(chart_bar)

        self.chart = ChartWidget()
        self.chart.set_mode("minute")
        right_layout.addWidget(self.chart, 1)

        # 报警日志
        glog = QGroupBox("报警/异动日志")
        glog_layout = QVBoxLayout(glog)
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumHeight(130)
        self.log_view.setStyleSheet("background:#111;color:#eee;font-family:monospace;")
        glog_layout.addWidget(self.log_view)
        right_layout.addWidget(glog)

        splitter.addWidget(right_panel)
        splitter.setSizes([380, 800])
        root.addWidget(splitter, 1)

        # ---- 用 QTabWidget 承载两个面板 ----
        tabs = QTabWidget()
        tabs.addTab(central, "自选盯盘")

        self.screener_panel = ScreenerPanel()
        tabs.addTab(self.screener_panel, "股票排行")

        # 顶层布局
        outer = QWidget()
        outer_layout = QVBoxLayout(outer)
        outer_layout.setContentsMargins(4, 4, 4, 4)
        outer_layout.addWidget(tabs)
        self.setCentralWidget(outer)

    # ================= 数据刷新 =================

    def refresh(self):
        """轮询最新行情并刷新界面（在 UI 线程中由 QTimer 触发）。"""
        if not self.watchlist:
            return
        try:
            quotes = fetch_quotes(self.watchlist)
        except Exception as e:
            self.statusBar().showMessage(f"获取行情失败: {e}")
            return
        if not quotes and self.last_quotes:
            quotes = self.last_quotes
        if not quotes:
            # 没有任何数据，至少把自选股票名称列出来，价格显示为暂无
            self._render_watchlist(None)
            self.statusBar().showMessage("未能获取行情数据，请检查网络")
            return
        self.last_quotes = quotes

        # 始终按 self.watchlist 的顺序渲染，确保每行对应正确的自选股
        self._render_watchlist(quotes)

        # 报警检测（异步做指标计算会较慢，这里用简单规则+缓存指标）
        for sym in self.watchlist:
            code = sym[2:]
            q = quotes.get(code)
            if q is None:
                continue
            ind = self.indicator_cache.get(code)
            self.alert_engine.check(code, q, indicators=ind)

        now = time.strftime("%H:%M:%S")
        self.statusBar().showMessage(f"上次刷新 {now} - 共 {len(self.watchlist)} 只")

    def _render_watchlist(self, quotes):
        """按 self.watchlist 顺序渲染整张表格，逐行对应自选股。"""
        self.table.setRowCount(len(self.watchlist))
        for row, sym in enumerate(self.watchlist):
            code = sym[2:]
            q = (quotes or {}).get(code)
            self._set_row(row, code, q)

    def _set_row(self, row, code, q):
        # 名称：有行情用接口名，否则用代码
        name = q["name"] if q else code
        if q is None:
            items_data = [code, name, "暂无数据", "--", "--", "--"]
            color = RED
            for col, text in enumerate(items_data):
                item = QTableWidgetItem(text)
                if col >= 2:
                    item.setForeground(QBrush(color))
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row, col, item)
            return

        up = (q["change"] or 0) >= 0
        color = RED if up else GREEN
        price = q["price"]
        # 停牌或价格为 0 时明确显示"停牌"，而不是空白
        price_text = f"{price:.2f}" if price else "停牌"
        items_data = [
            code, name,
            price_text,
            f"{q['change_pct']:+.2f}%" if price else "--",
            f"{q['change']:+.2f}" if price else "--",
            f"{q['volume']:,.0f}" if q["volume"] else "--",
        ]
        for col, text in enumerate(items_data):
            item = QTableWidgetItem(text)
            if col >= 2:  # 数字列上色
                item.setForeground(QBrush(color))
            item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, col, item)

    # ================= 添加/删除 =================

    def add_stock(self):
        raw = self.input.text().strip()
        if not raw:
            return
        try:
            symbol = normalize_code(raw)
        except ValueError as e:
            QMessageBox.warning(self, "输入错误", str(e))
            return
        code = symbol[2:]  # 6位数字代码
        if symbol not in self.watchlist:
            self.watchlist.append(symbol)
            self._save_config()
            self._apply_default_rules()
            self.input.clear()
            self.statusBar().showMessage(f"已添加 {symbol}")
            self.refresh()
            self._preload_klines([symbol])
        else:
            self.input.clear()
            self.statusBar().showMessage(f"{symbol} 已在自选列表")

    def remove_selected(self):
        row = self.table.currentRow()
        if row < 0:
            return
        if row < len(self.watchlist):
            symbol = self.watchlist.pop(row)
            self._save_config()
            self.statusBar().showMessage(f"已移除 {symbol}")
            self.refresh()

    # ================= 选中查看详情 =================

    def _on_select(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.watchlist):
            return
        symbol = self.watchlist[row]
        code = symbol[2:]
        if code in self.last_quotes:
            q = self.last_quotes[code]
            self.selected_title.setText(
                f"{q['name']} ({q['code']})  现价 {q['price']:.2f}  "
                f"{q['change']:+.2f} ({q['change_pct']:+.2f}%)")
        else:
            self.selected_title.setText(symbol)
        # 填充换手率/量比等实时行情指标
        self._update_live_indicators(symbol)
        # 后台线程加载数据，避免卡 UI
        self._load_if_missing(symbol, "kline")
        self._load_if_missing(symbol, "minute")
        # 立即从缓存渲染当前选中股票（若无缓存则显示为空/等待加载）
        self._render_chart_for(symbol)

    def _update_live_indicators(self, symbol):
        """从实时行情填充换手率、量比等指标标签。"""
        code = symbol[2:]
        q = self.last_quotes.get(code)
        live_map = {
            "turnover_rate": q["turnover_rate"] if q else None,
            "volume_ratio": q["volume_ratio"] if q else None,
        }
        for key, value in live_map.items():
            lab = self.indicators_labels.get(key)
            if not lab:
                continue
            if value is None:
                lab.setText("--")
                lab.setStyleSheet("")
            else:
                lab.setText(f"{value:.2f}")
                lab.setStyleSheet("")

    def _load_if_missing(self, symbol, kind):
        """按需加载：若指定类型数据尚未缓存则后台抓取。"""
        if kind == "minute" and symbol in self.minute_cache:
            return
        if kind == "kline" and symbol in self.kline_cache:
            return
        threading.Thread(
            target=self._load_detail, args=(symbol, kind), daemon=True).start()

    def _load_detail(self, symbol, kind):
        try:
            if kind == "minute":
                minute_data = fetch_minute(symbol)
                if not minute_data or not minute_data["prices"] or \
                        not any(minute_data["prices"]):
                    return
                self.minute_cache[symbol] = minute_data
                self.bridge.minute_ready.emit(symbol, minute_data)
            else:
                code = symbol[2:]
                klines = fetch_kline(symbol, count=120)
                if not klines:
                    return
                s = summarize(klines)
                # 附加精确技术形态分（基于真实K线的 MA/MACD/KDJ/RSI）
                tech = technical_score(klines)
                s["tech_score"] = tech["score"]
                s["tech_bullish"] = tech["bullish"]
                self.indicator_cache[code] = s
                ma_data = ma(klines)
                macd_data = macd(klines)
                self.bridge.detail_ready.emit(symbol, klines, ma_data, macd_data, s)
        except Exception as e:
            print(f"[ui_main] 加载 {symbol} {kind} 失败: {e}")

    def _on_chart_mode(self, index):
        mode = self.chart_mode.itemData(index)
        self.chart.set_mode(mode)
        row = self.table.currentRow()
        if 0 <= row < len(self.watchlist):
            symbol = self.watchlist[row]
            self._render_chart_for(symbol, force=(mode == "minute"))
        else:
            self.chart.clear_data()

    def _render_chart_for(self, symbol, force=False):
        """根据当前模式渲染图表；必要时触发数据加载。"""
        mode = self.chart.mode
        code = symbol[2:]
        if mode == "minute":
            md = self.minute_cache.get(symbol)
            if md is None:
                self.chart.clear_data()
                self._load_if_missing(symbol, "minute")
            else:
                self.chart.set_minute_data(md)
        else:
            cached = self.kline_cache.get(symbol)
            if cached:
                self.chart.set_kline_data(*cached)
            else:
                self.chart.clear_data()
                self._load_if_missing(symbol, "kline")

    # 由信号连接的槽（一定在 UI 线程执行）
    def apply_detail(self, symbol, klines, ma_data, macd_data, s):
        # 仅当当前选中的恰好是这个 symbol 时才更新右侧面板，避免串台
        row = self.table.currentRow()
        if not (0 <= row < len(self.watchlist)) or self.watchlist[row] != symbol:
            if symbol in self.watchlist:
                row2 = self.watchlist.index(symbol)
                self.table.selectRow(row2)
            else:
                return
        # 更新K线缓存（供模式切换时快速重绘）
        self.kline_cache[symbol] = (klines, ma_data, macd_data)
        if self.chart.mode == "kline":
            self.chart.set_kline_data(klines, ma_data, macd_data)
        # 更新指标标签
        for key, label in self.indicators_labels.items():
            if key in ("turnover_rate", "volume_ratio", "tech_score", "tech_state"):
                # 这些由专门逻辑单独填充
                continue
            v = s.get(key)
            if v is None:
                label.setText("--")
            else:
                label.setText(f"{v:.2f}" if isinstance(v, float) else str(v))
                label.setStyleSheet("")
        # 技术形态分（单独上色）
        tech_lab = self.indicators_labels.get("tech_score")
        if tech_lab is not None:
            ts = s.get("tech_score")
            if ts is None:
                tech_lab.setText("--")
                tech_lab.setStyleSheet("")
            else:
                tech_lab.setText(f"{ts:.1f}")
                if ts >= 60:
                    tech_lab.setStyleSheet("color:#ff6666;font-weight:bold;")
                elif ts >= 40:
                    tech_lab.setStyleSheet("color:#ffcc00;font-weight:bold;")
                else:
                    tech_lab.setStyleSheet("color:#66cc66;font-weight:bold;")
        state_lab = self.indicators_labels.get("tech_state")
        if state_lab is not None:
            bull = s.get("tech_bullish")
            if bull is None:
                state_lab.setText("--")
                state_lab.setStyleSheet("")
            else:
                state_lab.setText("多头形态" if bull else "空头/弱势")
                state_lab.setStyleSheet("color:#ff6666;font-weight:bold;"
                                        if bull else "color:#66cc66;font-weight:bold;")
        # 实时行情指标（换手率/量比）保持从 last_quotes 填充
        self._update_live_indicators(symbol)
        # 成交量异动高亮
        if s.get("volume_anomaly"):
            lab = self.indicators_labels.get("volume_ratio")
            if lab:
                lab.setStyleSheet("color:#ff8800;font-weight:bold;")

    def apply_minute(self, symbol, minute_data):
        row = self.table.currentRow()
        if not (0 <= row < len(self.watchlist)) or self.watchlist[row] != symbol:
            return
        if self.chart.mode == "minute":
            self.chart.set_minute_data(minute_data)

    # ================= 报警处理 =================

    def _on_alert(self, rule_result):
        self.bridge.alert_ready.emit(rule_result.message, rule_result.level)
        if self.notify_cb.isChecked():
            send_desktop_notification("A股盯盘提醒", rule_result.message)

    def append_log(self, message, level):
        color = {"alert": "#ff5555", "warning": "#ffaa00", "info": "#66ccff"}.get(level, "#eee")
        self.log_view.append(
            f'<span style="color:{color}">[{time.strftime("%H:%M:%S")}] {message}</span>')

    # ================= 数据预加载 =================

    def _preload_klines(self, codes=None):
        codes = codes or self.watchlist
        for symbol in codes:
            if symbol not in self.kline_cache:
                threading.Thread(
                    target=self._load_detail, args=(symbol, "kline"), daemon=True).start()
            if symbol not in self.minute_cache:
                threading.Thread(
                    target=self._load_detail, args=(symbol, "minute"), daemon=True).start()

    def closeEvent(self, event):
        self._save_config()
        event.accept()
