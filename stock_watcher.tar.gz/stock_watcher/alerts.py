# -*- coding: utf-8 -*-
"""
alerts.py —— 异动检测与涨跌提醒/报警模块。

内置多个可配置的监控规则，一旦触发会通过回调通知 GUI / 系统通知。

规则类型示例：
    1. 涨跌幅报警：涨幅超过 +X% 或跌幅超过 -X%
    2. 价格阈值报警：现价高于 / 低于某个价格
    3. 放量异动：量比超过阈值（由 indicators.detect_volume_anomaly 给出）
    4. 技术指标信号：如 RSI 超买（>70）/ 超卖（<30）
"""

import subprocess
import time


class RuleResult:
    """一条规则的检测结果。"""
    def __init__(self, rule_type, message, level="info", data=None):
        self.rule_type = rule_type
        self.message = message
        self.level = level      # info / warning / alert
        self.data = data or {}
        self.ts = time.strftime("%H:%M:%S")


class AlertEngine:
    """报警引擎：维护股票监控规则并执行检测。"""

    def __init__(self, notifier=None):
        """
        参数：
            notifier —— 可选的通知回调，形如 notify(rule_result)，
                        由 GUI 传入以触发界面弹窗/声音。
        """
        self.notifier = notifier
        # 每只股票的规则： { code: [ (rule_type, params), ... ] }
        self.rules = {}
        # 去重：避免同一条规则在连续刷新中重复报警
        self._last_fired = {}   # (code, rule_key) -> last_fire_time
        self._cooldown = 60     # 同一条规则触发后冷却时间（秒）

    # ---------- 配置 ----------

    def set_rules(self, code, rules):
        """设置某只股票的规则列表。
        rules 每一项: (rule_type, params_dict)
            rule_type: 'change_pct' | 'price' | 'volume' | 'rsi'
        """
        self.rules[code] = rules

    def clear_rules(self, code=None):
        if code:
            self.rules.pop(code, None)
        else:
            self.rules.clear()

    # ---------- 检测 ----------

    def check(self, code, quote, indicators=None):
        """对单只股票执行所有配置规则，返回触发的规则结果列表。"""
        hits = []
        for rule_type, params in self.rules.get(code, []) or []:
            result = self._check_rule(code, rule_type, params, quote, indicators)
            if result:
                hits.append(result)
        return hits

    def _check_rule(self, code, rule_type, params, quote, indicators):
        price = quote.get("price") or 0
        change_pct = quote.get("change_pct") or 0
        result = None

        if rule_type == "change_pct":
            up = params.get("up", 5)
            down = params.get("down", -5)
            if change_pct >= up:
                result = RuleResult(
                    "change_pct",
                    f"{quote.get('name', code)} 涨幅 {change_pct:+.2f}%，"
                    f"已突破 +{up}% 警报线",
                    level="alert",
                    data={"pct": change_pct})
            elif change_pct <= down:
                result = RuleResult(
                    "change_pct",
                    f"{quote.get('name', code)} 跌幅 {change_pct:+.2f}%，"
                    f"已跌破 {down}% 警报线",
                    level="warning",
                    data={"pct": change_pct})

        elif rule_type == "price":
            if params.get("above") is not None and price >= params["above"]:
                result = RuleResult(
                    "price",
                    f"{quote.get('name', code)} 现价 {price} 已突破上方目标 "
                    f"{params['above']}",
                    level="alert")
            elif params.get("below") is not None and price <= params["below"]:
                result = RuleResult(
                    "price",
                    f"{quote.get('name', code)} 现价 {price} 已跌破下方支撑 "
                    f"{params['below']}",
                    level="warning")

        elif rule_type == "volume":
            if indicators and indicators.get("volume_anomaly"):
                ratio = indicators.get("volume_ratio", 0)
                result = RuleResult(
                    "volume",
                    f"{quote.get('name', code)} 成交量异动！量比 {ratio}x，"
                    f"注意放量拉升/砸盘",
                    level="alert",
                    data={"ratio": ratio})

        elif rule_type == "rsi":
            if indicators:
                r6 = indicators.get("rsi6")
                if r6 is not None and r6 >= params.get("overbought", 70):
                    result = RuleResult(
                        "rsi",
                        f"{quote.get('name', code)} 六日强弱指标={r6:.1f} 进入超买区，"
                        f"注意回调风险",
                        level="warning")
                elif r6 is not None and r6 <= params.get("oversold", 30):
                    result = RuleResult(
                        "rsi",
                        f"{quote.get('name', code)} 六日强弱指标={r6:.1f} 进入超卖区，"
                        f"或存反弹机会",
                        level="info")

        # 冷却去重
        if result:
            key = (code, rule_type)
            now = time.time()
            if now - self._last_fired.get(key, 0) < self._cooldown:
                return None
            self._last_fired[key] = now
            if self.notifier:
                self.notifier(result)
        return result


def send_desktop_notification(title, message):
    """发送系统级桌面通知（Linux notify-send / macOS osascript）。"""
    try:
        subprocess.run(
            ["notify-send", title, message],
            timeout=3, check=False,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


if __name__ == "__main__":
    from stkquote import fetch_quotes, normalize_code

    engine = AlertEngine(notifier=lambda r: print("[触发]", r.level, r.message))
    symbol = normalize_code("600519")
    engine.set_rules(symbol, [
        ("change_pct", {"up": 5, "down": -5}),
        ("volume", {}),
        ("rsi", {"overbought": 70, "oversold": 30}),
    ])
    quote = fetch_quotes([symbol]).get("600519")
    print("当前行情:", quote["name"], quote["price"], f"{quote['change_pct']:+.2f}%")
    # 不传 indicators 时只测涨跌幅
    engine.check("600519", quote, indicators=None)
