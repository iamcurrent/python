# -*- coding: utf-8 -*-
"""
ui_kline.py —— 用 PyQt5 QPainter 自定义绘制的图表组件，支持两种模式：

    1. K线模式（'kline'）：日K蜡烛图 + MA5/10/20 均线 + 成交量 + MACD
    2. 分时模式（'minute'）：当日分时走势线 + 均价线 + 昨收参考线 + 成交量

不依赖 matplotlib，纯 Qt 绘制，保证在只装了 PyQt5 的环境也能运行。
"""

from PyQt5.QtCore import Qt, QPointF, QRectF
from PyQt5.QtGui import QColor, QPainter, QPen, QFont, QPainterPath, QBrush
from PyQt5.QtWidgets import QWidget

COLOR_UP = QColor(235, 70, 70)     # 红涨
COLOR_DOWN = QColor(40, 170, 100)  # 绿跌
COLOR_GRID = QColor(55, 55, 60)
COLOR_TEXT = QColor(195, 195, 195)
COLOR_BG = QColor(24, 24, 28)
COLOR_PRICE_LINE = QColor(240, 160, 40)   # 分时价格线（金色）
COLOR_AVG_LINE = QColor(90, 170, 255)     # 分时均价线（蓝色）


class ChartWidget(QWidget):
    """图表组件：K 线图 或 分时图。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(380)
        self.mode = "kline"          # 'kline' | 'minute'
        # K线数据
        self.klines = []
        self.ma_data = {}
        self.macd_data = {}
        # 分时数据
        self.minute = None

    # ---------- 模式 ----------

    def set_mode(self, mode):
        if mode in ("kline", "minute"):
            self.mode = mode
            self.update()

    def set_kline_data(self, klines, ma_data=None, macd_data=None):
        self.klines = klines or []
        self.ma_data = ma_data or {}
        self.macd_data = macd_data or {}
        self.update()

    def set_minute_data(self, minute):
        self.minute = minute
        self.update()

    def clear_data(self):
        self.klines = []
        self.ma_data = {}
        self.macd_data = {}
        self.minute = None
        self.update()

    # ---------- 绘制入口 ----------

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), COLOR_BG)
        if self.mode == "minute":
            self._paint_minute(painter)
        else:
            self._paint_kline(painter)

    # ================= K 线图 =================

    def _paint_kline(self, painter):
        n = len(self.klines)
        if n == 0:
            self._paint_empty(painter, "暂无K线数据")
            return

        w = self.width()
        h = self.height()
        price_h = int(h * 0.60)
        vol_h = int(h * 0.16)
        macd_h = h - price_h - vol_h

        max_bars = 80
        start = max(0, n - max_bars)
        visible = self.klines[start:]
        vn = len(visible)

        all_high = max(k[3] for k in visible)
        all_low = min(k[4] for k in visible)
        ma_vals = []
        for lst in self.ma_data.values():
            if lst:
                ma_vals.extend(v for v in lst[start:] if v is not None)
        if ma_vals:
            all_high = max(all_high, max(ma_vals))
            all_low = min(all_low, min(ma_vals))
        padding = (all_high - all_low) * 0.08 if all_high > all_low else all_high * 0.05 + 0.01
        y_top = 6
        y_bot_price = price_h - 18
        price_span = (all_high + padding) - (all_low - padding)

        x_step = w / vn
        candle_w = max(2.0, x_step * 0.55)

        def x_for(i):
            return i * x_step + x_step / 2

        def y_for(price, top, bot, span):
            return top + (all_high + padding - price) / span * (bot - top)

        # 网格 + 价格标签
        painter.setPen(QPen(COLOR_GRID, 1))
        for g in range(1, 5):
            gy = y_top + (y_bot_price - y_top) * g / 5.0
            painter.drawLine(0, int(gy), w, int(gy))
            price_at = all_high + padding - (g / 5.0) * price_span
            painter.setPen(COLOR_TEXT)
            painter.setFont(QFont("Sans Serif", 8))
            painter.drawText(2, int(gy - 4), f"{price_at:.2f}")
            painter.setPen(QPen(COLOR_GRID, 1))

        # K 线
        for idx, k in enumerate(visible):
            _, o, c, hi, lo, _ = k
            up = c >= o
            color = COLOR_UP if up else COLOR_DOWN
            x = x_for(idx)
            pen = QPen(color, 1)
            painter.setPen(pen)
            painter.drawLine(QPointF(x, y_for(hi, y_top, y_bot_price, price_span)),
                             QPointF(x, y_for(lo, y_top, y_bot_price, price_span)))
            top = y_for(max(o, c), y_top, y_bot_price, price_span)
            bot = y_for(min(o, c), y_top, y_bot_price, price_span)
            rect = QRectF(x - candle_w / 2, top, candle_w, max(bot - top, 1.0))
            painter.setPen(pen)
            painter.setBrush(QBrush(color))
            painter.drawRect(rect)
        painter.setBrush(Qt.NoBrush)

        # 均线
        self._draw_ma_line(painter, self.ma_data.get(5, []), start, vn, x_for,
                           y_for, y_top, y_bot_price, price_span, QColor(255, 200, 60))
        self._draw_ma_line(painter, self.ma_data.get(10, []), start, vn, x_for,
                           y_for, y_top, y_bot_price, price_span, QColor(90, 160, 255))
        self._draw_ma_line(painter, self.ma_data.get(20, []), start, vn, x_for,
                           y_for, y_top, y_bot_price, price_span, QColor(220, 120, 230))

        # 均线图例
        painter.setFont(QFont("Sans Serif", 8))
        self._legend(painter, "五日均线", QColor(255, 200, 60), 0)
        self._legend(painter, "十日均线", QColor(90, 160, 255), 1)
        self._legend(painter, "二十日均线", QColor(220, 120, 230), 2)

        # 成交量
        vol_y0 = price_h + 12
        vol_y1 = price_h + vol_h
        max_vol = max((k[5] for k in visible), default=1)
        painter.setPen(QPen(COLOR_GRID, 1))
        painter.drawLine(0, vol_y0 - 6, w, vol_y0 - 6)
        for idx, k in enumerate(visible):
            _, o, c, _, _, vol = k
            color = COLOR_UP if c >= o else COLOR_DOWN
            x = x_for(idx)
            hh = (vol / max_vol) * (vol_y1 - vol_y0 - 4)
            painter.fillRect(QRectF(x - candle_w / 2, vol_y1 - hh, candle_w, hh), color)

        # MACD
        macd_y0 = vol_y1 + 10
        macd_y1 = h - 6
        dif = self.macd_data.get("dif") or []
        dea = self.macd_data.get("dea") or []
        hist = self.macd_data.get("macd") or []
        painter.setPen(QPen(COLOR_GRID, 1))
        painter.drawLine(0, macd_y0 - 6, w, macd_y0 - 6)
        hist_vals = [v for v in hist[start:] if v is not None]
        if hist_vals:
            hmax = max(abs(v) for v in hist_vals) or 1.0
            for idx in range(vn):
                v = hist[start + idx] if start + idx < len(hist) else None
                if v is None:
                    continue
                x = x_for(idx)
                color = COLOR_UP if v >= 0 else COLOR_DOWN
                hh = (abs(v) / hmax) * (macd_y1 - macd_y0 - 20)
                mid = (macd_y1 + macd_y0) / 2
                if v >= 0:
                    painter.fillRect(QRectF(x - candle_w / 2, mid - hh, candle_w, hh), color)
                else:
                    painter.fillRect(QRectF(x - candle_w / 2, mid, candle_w, hh), color)

            def val_y_dif(v):
                return mid - v / hmax * ((macd_y1 - macd_y0 - 20) / 2)

            self._draw_plain_line(painter, dif, start, vn, x_for, val_y_dif,
                                  QColor(255, 220, 80))
            self._draw_plain_line(painter, dea, start, vn, x_for, val_y_dif,
                                  QColor(80, 200, 255))
            self._legend(painter, "离差值", QColor(255, 220, 80), 0)
            self._legend(painter, "信号线", QColor(80, 200, 255), 1)

    # ================= 分时图 =================

    def _paint_minute(self, painter):
        m = self.minute
        if not m or not m.get("prices") or not any(m["prices"]):
            self._paint_empty(painter, "暂无分时数据\n（非交易时段可能无法获取）")
            return

        w = self.width()
        h = self.height()
        price_h = int(h * 0.78)
        vol_h = h - price_h

        times = m["times"]
        n = len(times)
        prev_close = m.get("prev_close") or 0.0

        # 价格范围：以昨收为中心对称，兼顾高低点，仿真实分时图
        valid = [p for p in m["prices"] if p is not None]
        avg_valid = [a for a in m["avg_prices"] if a]
        hi = max(valid + avg_valid, default=prev_close)
        lo = min(valid + avg_valid, default=prev_close)
        if prev_close > 0:
            # 以涨跌停为界不太准确，这里用昨收±(高点-低点)的较大者做对称
            half = max(hi - prev_close, prev_close - lo) * 1.1
            if half < 0.001:
                half = prev_close * 0.02 or 0.01
            top_price = prev_close + half
            bot_price = prev_close - half
        else:
            span_rng = (hi - lo) or hi * 0.02 or 1.0
            top_price = hi + span_rng * 0.1
            bot_price = lo - span_rng * 0.1

        y_top = 6
        y_bot = price_h - 16
        x_step = w / n

        def x_for(i):
            return i * x_step + x_step / 2

        def y_for(price):
            return y_top + (top_price - price) / (top_price - bot_price) * (y_bot - y_top)

        # 网格（以昨收为中线）
        painter.setPen(QPen(COLOR_GRID, 1))
        mid_y = y_for(prev_close)
        painter.drawLine(0, int(mid_y), w, int(mid_y))
        # 上下各两条线（1/4, 1/2, 3/4 处）
        for frac in (0.25, 0.5, 0.75):
            gy = y_top + (y_bot - y_top) * frac
            painter.setPen(QPen(COLOR_GRID, 1, Qt.DashLine))
            painter.drawLine(0, int(gy), w, int(gy))
            price_at = top_price - (top_price - bot_price) * frac
            painter.setPen(COLOR_TEXT)
            painter.setFont(QFont("Sans Serif", 8))
            painter.drawText(2, int(gy - 4), f"{price_at:.2f}")

        # 昨收参考线标注（右侧）
        painter.setPen(QPen(COLOR_TEXT))
        painter.drawText(w - 60, int(mid_y - 4),
                         f"昨收 {prev_close:.2f}" if prev_close else "昨收 --")

        # 分时价格线
        pen_price = QPen(COLOR_PRICE_LINE, 1.6)
        painter.setPen(pen_price)
        path = QPainterPath()
        started = False
        for i in range(n):
            p = m["prices"][i]
            if p is None:
                continue
            pt = QPointF(x_for(i), y_for(p))
            if not started:
                path.moveTo(pt)
                started = True
            else:
                path.lineTo(pt)
        painter.drawPath(path)

        # 均价线
        painter.setPen(QPen(COLOR_AVG_LINE, 1.3))
        path2 = QPainterPath()
        started = False
        for i in range(n):
            a = m["avg_prices"][i]
            if a is None:
                continue
            pt = QPointF(x_for(i), y_for(a))
            if not started:
                path2.moveTo(pt)
                started = True
            else:
                path2.lineTo(pt)
        painter.drawPath(path2)

        # 时间轴标签（10:30 / 11:30 / 14:00 / 15:00 附近）
        painter.setPen(COLOR_TEXT)
        painter.setFont(QFont("Sans Serif", 8))
        mark_labels = {121 * 0: (0, "09:30")}
        # 计算 10:30, 11:30, 14:00, 15:00 的索引
        tick_times = ["1030", "1130", "1400", "1500"]
        for tt in tick_times:
            if tt in times:
                idx = times.index(tt)
                x = idx * x_step
                painter.drawText(int(max(x - 18, 2)), price_h - 2, tt[:2] + ":" + tt[2:])
        painter.drawText(2, price_h - 2, "09:30")

        # ---- 成交量区 ----
        vol_y0 = price_h + 10
        vol_y1 = h - 4
        max_vol = max((v for v in m["volumes"] if v is not None), default=1)
        painter.setPen(QPen(COLOR_GRID, 1))
        painter.drawLine(0, vol_y0 - 6, w, vol_y0 - 6)
        # 分时成交量：用每根与前一根的差值表示"当分钟成交量"
        prev_v = 0.0
        bar_w = max(1.0, x_step * 0.6)
        for i in range(n):
            v = m["volumes"][i]
            if v is None:
                continue
            delta = v - prev_v
            prev_v = v
            if delta < 0:
                delta = v  # 重置累计后异常，直接用当前累计
            color = COLOR_UP if (m["prices"][i] or 0) >= prev_close else COLOR_DOWN
            hh = (delta / max_vol) * (vol_y1 - vol_y0 - 2)
            painter.fillRect(QRectF(x_for(i) - bar_w / 2, vol_y1 - hh,
                                    bar_w, max(hh, 0.5)), color)

        # 图例
        painter.setFont(QFont("Sans Serif", 8))
        self._legend(painter, "分时价格", COLOR_PRICE_LINE, 0)
        self._legend(painter, "分时均价", COLOR_AVG_LINE, 1)

        # 当前价标注（左上）
        last = valid[-1] if valid else 0
        pct = (last - prev_close) / prev_close * 100 if prev_close else 0
        painter.setPen(COLOR_PRICE_LINE)
        painter.setFont(QFont("Sans Serif", 9, QFont.Bold))
        painter.drawText(8, 16, f"现价 {last:.2f}  {pct:+.2f}%")

    # ================= 工具方法 =================

    def _paint_empty(self, painter, text):
        painter.setPen(COLOR_TEXT)
        painter.setFont(QFont("Sans Serif", 11))
        painter.drawText(self.rect(), Qt.AlignCenter, text)

    def _legend(self, painter, name, color, row):
        """绘制右上角图例：色块 + 名称。"""
        x0 = self.width() - 200
        y = 8 + row * 16
        painter.setPen(QPen(color, 4))
        painter.drawLine(x0, y + 4, x0 + 12, y + 4)
        painter.setPen(COLOR_TEXT)
        painter.setFont(QFont("Sans Serif", 8))
        painter.drawText(x0 + 16, y + 8, name)

    def _draw_ma_line(self, painter, data, start, vn, x_for, y_for,
                      top, bot, span, color):
        painter.setPen(QPen(color, 1.4))
        path = QPainterPath()
        moved = False
        for i in range(vn):
            v = data[start + i] if start + i < len(data) else None
            if v is None:
                continue
            p = QPointF(x_for(i), y_for(v, top, bot, span))
            if not moved:
                path.moveTo(p)
                moved = True
            else:
                path.lineTo(p)
        painter.drawPath(path)

    def _draw_plain_line(self, painter, data, start, vn, x_for, y_for, color):
        painter.setPen(QPen(color, 1.4))
        path = QPainterPath()
        moved = False
        for i in range(vn):
            v = data[start + i] if start + i < len(data) else None
            if v is None:
                continue
            p = QPointF(x_for(i), y_for(v))
            if not moved:
                path.moveTo(p)
                moved = True
            else:
                path.lineTo(p)
        painter.drawPath(path)


# 兼容旧引用
KLineWidget = ChartWidget
