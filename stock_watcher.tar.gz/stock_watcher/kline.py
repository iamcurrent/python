# -*- coding: utf-8 -*-
"""
kline.py —— 抓取 A 股历史日 K 线（前复权），用于技术指标计算。

数据来源：
    首选：新浪财经 K 线接口（免费、无需 token、已实测稳定）
    备选：腾讯 ifzq.gtimg.cn 接口（如新浪不可用则回退）

统一返回结构：
    [ [date, open, close, high, low, volume], ... ] 按时间升序。
    其中 volume 单位统一为"手"（1手 = 100股）。
"""

import json
import time
import urllib.request

# 新浪 K 线接口
SINA_URL = ("https://quotes.sina.cn/cn/api/jsonp_v2.php/var%20_=/"
            "CN_MarketDataService.getKLineData")
# 腾讯 K 线接口（备选）
TENCENT_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"

HEADERS_SINA = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://finance.sina.com.cn",
}
HEADERS_TENCENT = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://gu.qq.com/",
}


def _fetch_sina(code: str, count: int) -> list:
    """新浪接口抓取。返回 [ [date,o,c,h,l,vol], ... ] 升序。"""
    url = f"{SINA_URL}?symbol={code}&scale=240&ma=no&datalen={count}"
    req = urllib.request.Request(url, headers=HEADERS_SINA)
    with urllib.request.urlopen(req, timeout=12) as resp:
        text = resp.read().decode("utf-8", errors="ignore")
    start = text.find("[")
    end = text.rfind("]")
    if start < 0 or end < 0 or end <= start:
        return []
    arr = json.loads(text[start:end + 1])
    result = []
    for k in arr:
        try:
            # 新浪 volume 单位为"股"，换算成"手"
            result.append([
                str(k["day"]),
                float(k["open"]),
                float(k["close"]),
                float(k["high"]),
                float(k["low"]),
                float(k["volume"]) / 100.0,
            ])
        except (KeyError, ValueError, TypeError):
            continue
    result.sort(key=lambda r: r[0])  # 保证升序
    return result


def _fetch_tencent(code: str, count: int, fq: str) -> list:
    """腾讯接口抓取（备选）。"""
    param = f"{code},day,,,{count},{fq}"
    url = f"{TENCENT_URL}?param={param}"
    req = urllib.request.Request(url, headers=HEADERS_TENCENT)
    with urllib.request.urlopen(req, timeout=12) as resp:
        obj = json.loads(resp.read().decode("utf-8"))
    data = obj.get("data", {}).get(code, {}) if obj else {}
    klines = data.get(fq + "day") or data.get("day") or []
    result = []
    for k in klines:
        try:
            result.append([
                str(k[0]),
                float(k[1]),
                float(k[2]),
                float(k[3]),
                float(k[4]),
                float(k[5]),
            ])
        except (IndexError, ValueError):
            continue
    result.sort(key=lambda r: r[0])
    return result


def fetch_kline(code: str, count: int = 120, fq: str = "qfq") -> list:
    """抓取某只股票最近 count 根日 K 线（默认前复权）。

    参数：
        code  —— 规范化代码，如 'sh600519'
        count —— 需要的 K 线根数
        fq    —— 复权方式（新浪恒为前复权；腾讯接口才区分 qfq/hfq/''）
    返回：
        [ [date, open, close, high, low, volume(手)], ... ] 升序
        失败时返回 []。
    """
    # 首选新浪
    try:
        rows = _fetch_sina(code, count)
        if rows:
            return rows
    except Exception as e:
        print(f"[kline] 新浪接口获取 {code} 失败: {e}")

    # 备选腾讯
    try:
        rows = _fetch_tencent(code, count, fq)
        if rows:
            return rows
    except Exception as e:
        print(f"[kline] 腾讯接口获取 {code} 失败: {e}")

    print(f"[kline] 获取 {code} K线失败（两个数据源均不可用）")
    return []


def fetch_klines(codes: list, count: int = 120, fq: str = "qfq") -> dict:
    """批量抓取多只股票的 K 线。

    返回：dict { code: [kline, ...] }
    """
    result = {}
    for code in codes:
        result[code] = fetch_kline(code, count, fq)
        time.sleep(0.2)  # 轻微限速，避免触发风控
    return result


if __name__ == "__main__":
    k = fetch_kline("sh600519", count=120)
    print(f"K线条数: {len(k)}")
    for row in k[-5:]:
        print(row)
