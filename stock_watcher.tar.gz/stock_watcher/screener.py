# -*- coding: utf-8 -*-
"""
screener.py —— 全市场股票扫描与排行筛选模块。

功能：
    1. scan_market()：并行分页抓取腾讯 rank 接口的全市场 A 股快照
       （每只含：代码/名称/现价/涨跌幅/换手率/量比/成交额/总市值/流通市值）
    2. build_sector_map()：并行拉取新浪行业板块成分股，建立"代码→所属行业板块"映射
    3. get_top()：按量比 / 换手率 / 涨跌幅排序，取前 N 名，并附加所属板块

数据源：
    - 全市场扫描：腾讯 proxy.finance.qq.com 排行接口（免费、无需 token、稳定）
    - 板块归属：新浪 money.finance.sina.com.cn 行业板块体系（免费、稳定）
"""

import json
import math
import os
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

# ------------------------------------------------------------------
# 常量
# ------------------------------------------------------------------
RANK_URL = ("https://proxy.finance.qq.com/cgi/cgi-bin/rank/hs/"
            "getBoardRankList?board_code=aStock&sort_type=price&direct=down"
            "&offset={offset}&count={count}")
RANK_PAGE_SIZE = 200          # 腾讯单页上限
MAX_MARKET_STOCKS = 7000      # 全市场扫描上限（实际约5500只）

SINA_BOARD_URL = "https://money.finance.sina.com.cn/q/view/newSinaHy.php"
SINA_CONCEPT_URL = "https://money.finance.sina.com.cn/q/view/newFLJK.php?param=class"
SINA_NODE_URL = ("https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
                 "Market_Center.getHQNodeData?page={page}&num={num}&sort=symbol"
                 "&asc=1&node={node}")

SECTOR_CACHE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "sector_cache.json")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
}
HEADERS_TENCENT = {"User-Agent": HEADERS["User-Agent"], "Referer": "https://gu.qq.com/"}
HEADERS_SINA = {"User-Agent": HEADERS["User-Agent"], "Referer": "https://finance.sina.com.cn/"}


# ------------------------------------------------------------------
# 全市场扫描
# ------------------------------------------------------------------
def _fetch_rank_page(offset: int) -> list:
    """拉取腾讯排行接口的一页。"""
    url = RANK_URL.format(offset=offset, count=RANK_PAGE_SIZE)
    req = urllib.request.Request(url, headers=HEADERS_TENCENT)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            obj = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return []
    rank_list = obj.get("data", {}).get("rank_list") if obj else None
    return rank_list or []


def _parse_rank_item(item: dict) -> dict:
    """把腾讯 rank 的一条记录整理成统一结构。"""
    def _f(key, default=None):
        v = item.get(key)
        if v in (None, "", "-"):
            return default
        try:
            return float(v)
        except (TypeError, ValueError):
            return default

    return {
        "symbol": item.get("code", ""),        # 如 sh600519
        "code": (item.get("code") or "")[2:],  # 6位代码
        "name": item.get("name", ""),
        "price": _f("zxj", 0.0),               # 现价
        "change_pct": _f("zdf", 0.0),          # 涨跌幅%
        "change": _f("zd", 0.0),               # 涨跌额
        "turnover_rate": _f("hsl", 0.0),       # 换手率%
        "volume_ratio": _f("lb", 0.0),         # 量比
        "amount": _f("turnover", 0.0),         # 成交额(万元)
        "volume": _f("volume", 0.0),           # 成交量(手)
        "total_mv": _f("zsz", 0.0),            # 总市值(亿)
        "float_mv": _f("ltsz", 0.0),           # 流通市值(亿)
        # 近期历史表现（%）
        "zdf_d5": _f("zdf_d5", None),          # 5日涨跌幅
        "zdf_d10": _f("zdf_d10", None),        # 10日涨跌幅
        "zdf_d20": _f("zdf_d20", None),        # 20日涨跌幅
        "zdf_d60": _f("zdf_d60", None),        # 60日涨跌幅
    }


def scan_market(num_workers: int = 8) -> list:
    """并行扫描全市场 A 股，返回行情记录列表。

    返回：list[ dict ]，每项含 symbol/code/name/price/change_pct/turnover_rate/
          volume_ratio/amount/volume/total_mv/float_mv
    """
    pages = []
    offsets = list(range(0, MAX_MARKET_STOCKS, RANK_PAGE_SIZE))
    with ThreadPoolExecutor(max_workers=num_workers) as ex:
        pages = list(ex.map(_fetch_rank_page, offsets))

    results = []
    seen = set()
    for page in pages:
        for item in page:
            rec = _parse_rank_item(item)
            if rec["code"] and rec["symbol"] not in seen and rec["name"]:
                seen.add(rec["symbol"])
                results.append(rec)
    return results


# ------------------------------------------------------------------
# 板块归属（新浪行业板块）
# ------------------------------------------------------------------
def _fetch_sina_boards(url=None) -> list:
    """获取新浪行业（或概念）板块列表，返回 [(node, 板块名), ...]。"""
    url = url or SINA_BOARD_URL
    req = urllib.request.Request(url, headers=HEADERS_SINA)
    with urllib.request.urlopen(req, timeout=12) as resp:
        text = resp.read().decode("gbk", errors="ignore")
    import re
    items = re.findall(r'"(\w+)":"([^"]*)"', text)
    boards = []
    for code, val in items:
        parts = val.split(",")
        name = parts[1] if len(parts) > 1 else code
        boards.append((code, name))
    return boards


def _fetch_board_stocks(node: str) -> set:
    """拉取某个板块的全部成分股代码集合（如 sz002623）。"""
    codes = set()
    page = 1
    while True:
        url = SINA_NODE_URL.format(page=page, num=100, node=node)
        req = urllib.request.Request(url, headers=HEADERS_SINA)
        try:
            with urllib.request.urlopen(req, timeout=12) as resp:
                txt = resp.read().decode("gbk", errors="ignore")
            import json as _json
            arr = _json.loads(txt)
        except Exception:
            break
        if not arr:
            break
        for it in arr:
            sym = it.get("symbol")
            if sym:
                codes.add(sym)
        if len(arr) < 100:
            break
        page += 1
        if page > 30:
            break
    return codes


def build_sector_map(include_concept: bool = True) -> dict:
    """并行拉取板块成分股，返回 {symbol: 板块名} 映射。

    先取行业板块（语义清晰），再用概念板块补充行业未覆盖的股票，
    保证覆盖率最大化。
    例如：{'sh600519': '酿酒行业', 'sz300750': '电器行业', 'sz301206': '食品饮料', ...}
    """
    symbol_to_board = {}

    def fetch_group(boards):
        """并行拉取一组板块成分。返回首出现优先的映射。"""
        local = {}

        def one(node_name):
            node, name = node_name
            return node, name, _fetch_board_stocks(node)

        with ThreadPoolExecutor(max_workers=12) as ex:
            results = ex.map(one, boards)
            for _node, name, codes in results:
                for sym in codes:
                    if sym not in local:
                        local[sym] = name
        return local

    # 行业板块
    try:
        industry = fetch_group(_fetch_sina_boards(SINA_BOARD_URL))
        symbol_to_board.update(industry)
    except Exception as e:
        print(f"[screener] 获取行业板块失败: {e}")

    # 概念板块补充
    if include_concept:
        try:
            concepts = fetch_group(_fetch_sina_boards(SINA_CONCEPT_URL))
            for sym, name in concepts.items():
                if sym not in symbol_to_board:
                    symbol_to_board[sym] = name
        except Exception as e:
            print(f"[screener] 获取概念板块失败: {e}")

    return symbol_to_board


def _save_sector_map(mapping: dict):
    try:
        with open(SECTOR_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(mapping, f, ensure_ascii=False)
    except Exception:
        pass


def _load_sector_map() -> dict:
    if os.path.exists(SECTOR_CACHE_FILE):
        try:
            with open(SECTOR_CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


# ------------------------------------------------------------------
# 排行筛选
# ------------------------------------------------------------------
METRIC_MAP = {
    "lb": "volume_ratio",     # 量比
    "hsl": "turnover_rate",   # 换手率
    "zdf": "change_pct",      # 涨跌幅
}


def top_by_metric(records: list, metric: str, n: int = 100,
                  sector_map: dict = None) -> list:
    """按指定指标取前 n 名，并附加所属板块。

    metric：'lb'(量比) | 'hsl'(换手率) | 'zdf'(涨跌幅)
    返回：list[ dict ]，每项为 record + {'sector': 板块名}
    """
    key = METRIC_MAP.get(metric)
    if not key:
        key = "volume_ratio"
    # 按指标降序
    ranked = sorted(records, key=lambda r: r.get(key) or 0, reverse=True)
    top = ranked[:n]
    result = []
    for rec in top:
        out = dict(rec)
        sym = rec["symbol"]
        out["sector"] = (sector_map or {}).get(sym, "--")
        result.append(out)
    return result


# ------------------------------------------------------------------
# 综合评分选股
# ------------------------------------------------------------------
# 综合评分权重配置
SCORE_WEIGHTS = {
    "turnover_rate": 0.15,   # 换手率活跃度
    "volume_ratio": 0.20,    # 量比（放量程度）
    "amount": 0.20,          # 成交额（资金关注度）
    "momentum": 0.25,        # 近期动量（当日+5日+10日表现）
    "trend_structure": 0.20, # 技术形态：均线趋势结构（多头排列近似）
}


def _clip(x, lo, hi):
    return max(lo, min(hi, x))


def _score_turnover(v):
    """换手率得分：适度活跃最佳。2%-15% 中间区高分，过低或异常过高扣分。"""
    if v is None or v <= 0:
        return 0
    if v <= 1:
        return v * 20          # 0-1%线性到20
    if v <= 5:
        return 20 + (v - 1) * 15   # 1-5% -> 20-80
    if v <= 15:
        return 80 + (v - 5) * 1.5  # 5-15% -> 80-95
    if v <= 25:
        return 95 - (v - 15) * 3   # 15-25% 逐步回落
    return max(30, 95 - (v - 25) * 2)  # 过高换手（疯狂炒作）回落


def _score_volume_ratio(v):
    """量比得分：1-3 为温和放量高分，过大略扣分，过小（缩量）低分。"""
    if v is None or v <= 0:
        return 0
    if v <= 0.5:
        return v * 40          # 缩量 0-20
    if v <= 1:
        return 20 + (v - 0.5) * 60   # 0.5-1 -> 20-50
    if v <= 2.5:
        return 50 + (v - 1) * 22     # 1-2.5 -> 50-83
    if v <= 4:
        return 83 + (v - 2.5) * 6    # 2.5-4 -> 83-92
    if v <= 8:
        return 92 - (v - 4) * 3      # 4-8 回落
    return max(40, 80 - (v - 8) * 2) # 极端放量回落


def _score_amount(v):
    """成交额得分：用对数归一化，兼顾客观资金体量但避免大票垄断。"""
    if v is None or v <= 0:
        return 0
    # 成交额单位是万元，取 log10
    log_a = math.log10(v)
    # 典型区间: 1千万(1e3万, log=3) ~ 100亿(1e6万, log=6)
    score = (log_a - 2.5) / (6.0 - 2.5) * 100
    return _clip(score, 0, 100)


def _score_momentum(rec):
    """近期动量得分：综合当日、5日、10日涨跌幅。"""
    today = rec.get("change_pct") or 0
    d5 = rec.get("zdf_d5")
    d10 = rec.get("zdf_d10")
    # 用各周期涨跌幅的加权，映射到 0-100（以 ±20% 为满分/零分区间）
    vals = [(today, 0.4), (d5 if d5 is not None else today, 0.3),
            (d10 if d10 is not None else today, 0.3)]
    momentum = sum(w * v for v, w in vals)
    # 把动量%映射到0-100：-20%->0, 0->50, +20%->100
    return _clip(50 + momentum * 2.5, 0, 100)


def _score_trend_structure(rec):
    """技术形态（趋势结构）得分：用 5/10/20 日涨跌幅的阶梯结构近似均线排列。

    逻辑：
        - 5/10/20 日涨跌幅都为正 -> 阶段性多头（价在 MA5/10/20 上方近似）
        - 且 短期涨幅 >= 中期 >= 长期（价格抬升、均线向上发散）-> 均线多头排列近似
        - 全部为负 -> 空头，低分
    这样无需逐只抓 K 线即可在全市场排行中纳入"趋势结构"这一技术形态维度。
    """
    d5 = rec.get("zdf_d5")
    d10 = rec.get("zdf_d10")
    d20 = rec.get("zdf_d20")
    if d5 is None or d10 is None or d20 is None:
        # 缺数据时退化为只参考最近 5 日表现
        d5 = rec.get("change_pct") or 0
        base = _clip(50 + d5 * 2.5, 0, 100)
        return base

    # 1) 多头结构：5>=10 且 10>=20（短强于长，均线向上发散，多头排列近似）
    bull_aligned = (d5 >= d10 >= d20) and d20 > 0
    # 2) 空头结构：5<=10<=20 且 20<0（长短均弱，空头排列近似）
    bear_aligned = (d5 <= d10 <= d20) and d20 < 0

    # 趋势强度：以 20 日涨幅为锚，±15% 映射到 0-100
    base = _clip(50 + d20 * 3.0, 0, 100)

    if bull_aligned:
        # 多头排列给高分基础 + 趋势强度
        return _clip(60 + base * 0.4, 0, 100)
    if bear_aligned:
        # 空头排列大幅压分
        return _clip(base * 0.35, 0, 100)
    # 一般缠绕状态：以 20 日趋势为主，略微偏向多头
    return _clip(base, 0, 100)


def composite_score(rec: dict) -> float:
    """计算单只股票的综合评分（0-100）。

    综合考量：换手率、量比、成交额、近期历史表现（动量）、技术形态（趋势结构）。
    """
    s = (_score_turnover(rec.get("turnover_rate")) * SCORE_WEIGHTS["turnover_rate"]
         + _score_volume_ratio(rec.get("volume_ratio")) * SCORE_WEIGHTS["volume_ratio"]
         + _score_amount(rec.get("amount")) * SCORE_WEIGHTS["amount"]
         + _score_momentum(rec) * SCORE_WEIGHTS["momentum"]
         + _score_trend_structure(rec) * SCORE_WEIGHTS["trend_structure"])
    return round(s, 2)


def trend_structure_score(rec: dict) -> float:
    """暴露单维度技术形态（趋势结构）得分，便于展示/调试。"""
    return round(_score_trend_structure(rec), 2)


def top_by_score(records: list, n: int = 100, sector_map: dict = None) -> list:
    """按综合评分取前 n 名，并附加板块与评分。

    返回：list[ dict ]，每项为 record + {'sector': 板块名, 'score': 综合评分,
          'trend_structure': 技术形态(趋势结构)分}
    """
    scored = []
    for rec in records:
        out = dict(rec)
        out["score"] = composite_score(rec)
        out["trend_structure"] = trend_structure_score(rec)
        scored.append(out)
    ranked = sorted(scored, key=lambda r: r["score"], reverse=True)
    top = ranked[:n]
    for rec in top:
        sym = rec["symbol"]
        rec["sector"] = (sector_map or {}).get(sym, "--")
    return top


if __name__ == "__main__":
    import time
    t0 = time.time()
    print("扫描全市场...")
    market = scan_market()
    print(f"全市场扫描完成: {len(market)} 只, 耗时 {time.time()-t0:.1f}s")

    print("获取板块映射（首次较慢，之后缓存）...")
    sector = _load_sector_map()
    if not sector:
        sector = build_sector_map()
        _save_sector_map(sector)
        print(f"板块映射建立完成: {len(sector)} 只")
    else:
        print(f"使用缓存板块映射: {len(sector)} 只")

    top = top_by_metric(market, "lb", 10, sector)
    print("\n=== 量比 Top10 ===")
    for i, r in enumerate(top, 1):
        print(f"{i:>2}. {r['name']}({r['code']}) 量比{r['volume_ratio']:.2f} "
              f"涨跌{r['change_pct']:+.2f}% 换手{r['turnover_rate']:.2f}% "
              f"板块:{r['sector']}")
