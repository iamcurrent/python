# -*- coding: utf-8 -*-
"""
minute.py —— 抓取并解析 A 股当日分时数据（分时走势图用）。

数据来源：腾讯 ifzq.gtimg.cn 分时接口（免费，无需 token）。

分时接口返回结构：
    data[code]['data'] = {
        'date': '20260908',
        'data': ['0930 1318.00 101 13311800.00', '0931 1322.32 429 56602684.00', ...]
    }
    每条: "HHMM 价格 成交量(手) 成交额(元)"

    成交量与成交额均为"到当前时刻的累计值"。
"""

import json
import urllib.request

MINUTE_URL = "https://web.ifzq.gtimg.cn/appstock/app/minute/query"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://gu.qq.com/",
}


def fetch_minute(symbol: str) -> dict:
    """抓取某只股票当日分时数据。

    参数：symbol —— 规范化代码，如 'sh600519'
    返回 dict：
        {
            'code': str, 'name': str, 'date': str,
            'prev_close': float, 'open': float, 'high': float, 'low': float,
            'last': float,
            'times': [str,...],          # ['0930', '0931', ...] 一天的时间轴（全部241个）
            'prices': [float,...],       # 分时价格（对齐 times；无数据处为 None）
            'avg_prices': [float,...],   # 分时均价（对齐 times）
            'volumes': [float,...],      # 分时累计成交量（对齐 times）
            'amounts': [float,...],      # 分时累计成交额
        }
    """
    url = f"{MINUTE_URL}?code={symbol}"
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=10) as resp:
        obj = json.loads(resp.read().decode("utf-8"))

    node = obj.get("data", {}).get(symbol, {})
    qt = node.get("qt", {}).get(symbol, [])
    data_node = node.get("data", {})
    rows = data_node.get("data", []) or []
    date = data_node.get("date", "")

    # 从 qt 字段（腾讯实时行情）取基本价格信息
    def _q(i, default=""):
        return qt[i] if i < len(qt) and qt[i] else default

    try:
        prev_close = float(_q(4)) if _q(4) else 0.0
    except ValueError:
        prev_close = 0.0

    # 全天时间轴：09:30~11:30 与 13:01~15:00
    times = _build_time_axis()
    prices = [None] * len(times)
    volumes = [None] * len(times)
    amounts = [None] * len(times)
    time_index = {t: i for i, t in enumerate(times)}

    for row in rows:
        parts = row.split()
        if len(parts) < 4:
            continue
        t, price_s, vol_s, amt_s = parts[0], parts[1], parts[2], parts[3]
        idx = time_index.get(t)
        if idx is None:
            continue
        try:
            prices[idx] = float(price_s)
            volumes[idx] = float(vol_s)
            amounts[idx] = float(amt_s)
        except ValueError:
            continue

    # 计算分时均价 = 累计成交额 / 累计成交量（单位：万元换算）
    avg_prices = [None] * len(times)
    for i in range(len(times)):
        if volumes[i] and amounts[i]:
            # amounts 单位是元，成交量单位是手(100股)，均价=(元)/(手*100)
            avg_prices[i] = amounts[i] / (volumes[i] * 100.0) if volumes[i] else None

    # 有效价格的最值
    valid = [p for p in prices if p is not None]
    high = max(valid) if valid else 0.0
    low = min(valid) if valid else 0.0
    last = valid[-1] if valid else 0.0
    first_valid = next((p for p in prices if p is not None), 0.0)  # 首笔=开盘近似

    return {
        "code": symbol[2:],
        "name": _q(1),
        "date": date,
        "prev_close": prev_close,
        "open": first_valid,
        "high": high,
        "low": low,
        "last": last,
        "times": times,
        "prices": prices,
        "avg_prices": avg_prices,
        "volumes": volumes,
        "amounts": amounts,
    }


def _build_time_axis() -> list:
    """生成 A 股一个交易日的分钟时间轴（09:30~11:30, 13:01~15:00）。"""
    times = []
    # 上午 09:30 ~ 11:30
    h, m = 9, 30
    while (h, m) <= (11, 30):
        times.append(f"{h:02d}{m:02d}")
        m += 1
        if m == 60:
            m = 0
            h += 1
    # 下午 13:01 ~ 15:00
    h, m = 13, 1
    while (h, m) <= (15, 0):
        times.append(f"{h:02d}{m:02d}")
        m += 1
        if m == 60:
            m = 0
            h += 1
    return times


if __name__ == "__main__":
    d = fetch_minute("sh600519")
    print("名称:", d["name"], "日期:", d["date"], "昨收:", d["prev_close"])
    print("现价:", d["last"], "最高:", d["high"], "最低:", d["low"])
    valid_pts = sum(1 for p in d["prices"] if p is not None)
    print("有效分时点数:", valid_pts, "/", len(d["times"]))
    # 打印最后几个有效点
    pairs = [(t, p) for t, p in zip(d["times"], d["prices"]) if p is not None]
    print("最后5个点:", pairs[-5:])
    # 均价示例
    avg_valid = [(t, a) for t, a in zip(d["times"], d["avg_prices"]) if a]
    print("均价点数量:", len(avg_valid), "最后均价:", avg_valid[-1] if avg_valid else None)
