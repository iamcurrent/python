# -*- coding: utf-8 -*-
"""
indicators.py —— 技术指标计算模块（纯 Python 实现，无第三方依赖）

支持指标：
    - MA  (移动平均线)        : MA5 / MA10 / MA20 / MA60
    - EMA (指数移动平均，辅助用)
    - MACD                     : DIF, DEA, MACD 柱
    - RSI (相对强弱指标)      : RSI6 / RSI12 / RSI24
    - KDJ (随机指标)          : K, D, J
    - 成交量异动判断

K 线数据结构（来自 kline.py）：
    [ [date, open, close, high, low, volume], ... ] 升序
"""


def _sma(values, n):
    """简单移动平均，输出长度与输入相同，前 n-1 位为 None。"""
    out = [None] * len(values)
    if n <= 0 or len(values) < n:
        return out
    s = sum(values[:n])
    out[n - 1] = s / n
    for i in range(n, len(values)):
        s += values[i] - values[i - n]
        out[i] = s / n
    return out


def _ema(values, n):
    """指数移动平均，输出长度与输入相同，前 n-1 位为 None。"""
    out = [None] * len(values)
    if n <= 0 or not values:
        return out
    k = 2.0 / (n + 1)
    ema = None
    for i, v in enumerate(values):
        ema = v if ema is None else v * k + ema * (1 - k)
        out[i] = ema
    return out


def ma(klines, periods=(5, 10, 20, 60)):
    """计算 MA。返回 dict: period -> 列表（None 为前导空值）。"""
    closes = [k[2] for k in klines]
    result = {}
    for p in periods:
        result[p] = _sma(closes, p)
    return result


def macd(klines, fast=12, slow=26, signal=9):
    """计算 MACD。返回 dict: {'dif':[], 'dea':[], 'macd':[]}。"""
    closes = [k[2] for k in klines]
    ema_fast = _ema(closes, fast)
    ema_slow = _ema(closes, slow)
    dif = [None if (f is None or s is None) else f - s
           for f, s in zip(ema_fast, ema_slow)]
    # DEA = DIF 的 EMA（窗口为 signal）
    valid_dif = [d if d is not None else 0.0 for d in dif]
    dea = _ema(valid_dif, signal)
    macd_hist = [None if (d is None or e is None) else (d - e) * 2
                 for d, e in zip(dif, dea)]
    return {"dif": dif, "dea": dea, "macd": macd_hist}


def rsi(klines, periods=(6, 12, 24)):
    """计算 RSI。返回 dict: period -> 列表。"""
    closes = [k[2] for k in klines]
    result = {}
    for n in periods:
        out = [None] * len(closes)
        if len(closes) <= n:
            result[n] = out
            continue
        gains = [0.0] * len(closes)
        losses = [0.0] * len(closes)
        for i in range(1, len(closes)):
            diff = closes[i] - closes[i - 1]
            if diff > 0:
                gains[i] = diff
            else:
                losses[i] = -diff
        # Wilder 平滑
        avg_gain = sum(gains[1:n + 1]) / n
        avg_loss = sum(losses[1:n + 1]) / n
        for i in range(n, len(closes)):
            if i > n:
                avg_gain = (avg_gain * (n - 1) + gains[i]) / n
                avg_loss = (avg_loss * (n - 1) + losses[i]) / n
            if avg_loss == 0:
                out[i] = 100.0
            else:
                rs = avg_gain / avg_loss
                out[i] = 100 - 100 / (1 + rs)
        result[n] = out
    return result


def kdj(klines, n=9, m1=3, m2=3):
    """计算 KDJ。返回 dict: {'k':[], 'd':[], 'j':[]}。"""
    highs = [k[3] for k in klines]
    lows = [k[4] for k in klines]
    closes = [k[2] for k in klines]
    k = [None] * len(klines)
    d = [None] * len(klines)
    j = [None] * len(klines)
    if len(klines) < n:
        return {"k": k, "d": d, "j": j}
    prev_k = 50.0
    prev_d = 50.0
    for i in range(n - 1, len(klines)):
        window_high = max(highs[i - n + 1:i + 1])
        window_low = min(lows[i - n + 1:i + 1])
        rsv = 50.0 if window_high == window_low else \
            (closes[i] - window_low) / (window_high - window_low) * 100
        cur_k = (m1 - 1) / m1 * prev_k + 1.0 / m1 * rsv
        cur_d = (m2 - 1) / m2 * prev_d + 1.0 / m2 * cur_k
        cur_j = 3 * cur_k - 2 * cur_d
        k[i] = cur_k
        d[i] = cur_d
        j[i] = cur_j
        prev_k = cur_k
        prev_d = cur_d
    return {"k": k, "d": d, "j": j}


def detect_volume_anomaly(klines, threshold=2.0, lookback=5):
    """检测成交量异动（放量）。

    规则：最新一根K线成交量 > 前 lookback 根均量 * threshold，判定为显著放量。
    返回 dict:
        { 'anomaly': bool, 'volume': float, 'avg': float, 'ratio': float }
    """
    if len(klines) < lookback + 1:
        return {"anomaly": False, "volume": 0, "avg": 0, "ratio": 0}
    volumes = [k[5] for k in klines]
    cur = volumes[-1]
    avg = sum(volumes[-1 - lookback:-1]) / lookback
    ratio = cur / avg if avg > 0 else 0
    return {"anomaly": ratio > threshold,
            "volume": cur, "avg": avg, "ratio": round(ratio, 2)}


def summarize(klines):
    """汇总最近一个交易日的所有技术指标，方便界面展示。"""
    if not klines:
        return {}
    ma_dict = ma(klines)
    macd_dict = macd(klines)
    rsi_dict = rsi(klines)
    kdj_dict = kdj(klines)
    vol = detect_volume_anomaly(klines)

    def last(lst, default=None):
        return lst[-1] if lst and lst[-1] is not None else default

    return {
        "ma5": last(ma_dict[5]),
        "ma10": last(ma_dict[10]),
        "ma20": last(ma_dict[20]),
        "ma60": last(ma_dict[60]),
        "dif": last(macd_dict["dif"]),
        "dea": last(macd_dict["dea"]),
        "macd": last(macd_dict["macd"]),
        "rsi6": last(rsi_dict[6]),
        "rsi12": last(rsi_dict[12]),
        "rsi24": last(rsi_dict[24]),
        "kdj_k": last(kdj_dict["k"]),
        "kdj_d": last(kdj_dict["d"]),
        "kdj_j": last(kdj_dict["j"]),
        "volume_ratio": vol["ratio"],
        "volume_anomaly": vol["anomaly"],
    }


# ------------------------------------------------------------------
# 精确技术形态评分（基于真实 K 线）
# ------------------------------------------------------------------
# 综合 MA / MACD / KDJ / RSI 等多个经典技术信号，给出一个 0-100 的
# "技术形态分"，用于评估单股（自选/详情）的趋势结构与买点质量。
# 分数越高代表多头形态越强、结构越健康。

TECH_WEIGHTS = {
    "ma_align": 0.35,     # 均线多头排列
    "price_vs_ma": 0.15,  # 价格在主要均线上方
    "macd": 0.25,         # MACD 金叉 / 零轴上方
    "kdj": 0.15,          # KDJ 金叉 / K>D
    "rsi": 0.10,          # RSI 处于强势健康区间
}


def _ma_align_score(ma_dict):
    """均线多头排列评分：MA5>MA10>MA20>MA60 为满分多头，依次递减。"""
    closes = None
    a5 = ma_dict.get(5)
    a10 = ma_dict.get(10)
    a20 = ma_dict.get(20)
    a60 = ma_dict.get(60)
    if a5 is None or a10 is None or a20 is None or a60 is None:
        return 50.0
    score = 0.0
    score += 100 if a5 > a10 else 0
    score += 100 if a10 > a20 else 0
    score += 100 if a20 > a60 else 0
    return score / 3.0


def _price_vs_ma_score(price, ma_dict):
    """价格相对主要均线的位置评分：站上所有关键均线得分最高。"""
    periods = [5, 10, 20, 60]
    valid = [ma_dict.get(p) for p in periods]
    valid = [v for v in valid if v is not None]
    if not valid or not price:
        return 50.0
    above = sum(1 for v in valid if price > v)
    return above / len(valid) * 100.0


def _macd_score(macd_dict):
    """MACD 形态评分：DIF>DEA 且 DIF>0 为完美多头；金叉/零轴上加分。"""
    dif = macd_dict.get("dif")
    dea = macd_dict.get("dea")
    if dif is None or dea is None:
        return 50.0
    score = 0.0
    if dif > dea:          # 金叉状态
        score += 60
    else:
        score += 15
    if dif > 0:            # 零轴上方（多头势力）
        score += 40
    else:
        score += 10
    return score


def _kdj_score(kdj_dict):
    """KDJ 形态评分：K>D 多头，超买回落不给满分。"""
    k = kdj_dict.get("k")
    d = kdj_dict.get("d")
    j = kdj_dict.get("j")
    if k is None or d is None:
        return 50.0
    score = 0.0
    if k > d:              # 金叉 / K 在 D 上方
        score += 55
    else:
        score += 15
    if k < 20:             # 低位金叉潜力
        score += 20
    elif 20 <= k <= 80:
        score += 25
    else:                  # 高位(超买)回落
        score += 5
    return score


def _rsi_healthy_score(rsi24):
    """RSI 健康区间评分：50-70 强势未超买为最优。"""
    if rsi24 is None:
        return 50.0
    if 50 <= rsi24 <= 66:       # 强势健康区
        return 90
    if 40 <= rsi24 < 50:        # 偏弱但未走坏
        return 55
    if 66 < rsi24 <= 75:        # 强势但接近超买
        return 70
    if 75 < rsi24 <= 85:        # 超买区
        return 35
    if rsi24 > 85:              # 严重超买
        return 15
    if rsi24 < 30:              # 超卖（可能是反转起点，中性偏低）
        return 30
    return 40


def technical_score(klines):
    """基于真实 K 线计算单股"技术形态分"（0-100）。

    综合：均线多头排列、价格在均线上方、MACD、KDJ、RSI 健康度。
    返回 dict:
        {
            'score': float,          # 0-100 综合技术形态分
            'ma_align': float,       # 各分量分数（便于调试/展示）
            'price_vs_ma': float,
            'macd': float,
            'kdj': float,
            'rsi': float,
            'bullish': bool,         # score>=60 视为多头形态
        }
    """
    if not klines or len(klines) < 20:
        return {"score": 50.0, "bullish": False,
                "ma_align": 50, "price_vs_ma": 50, "macd": 50, "kdj": 50, "rsi": 50}
    close = klines[-1][2]
    ma_dict = _ma_last(ma(klines, (5, 10, 20, 60)))
    macd_dict = _macd_last(macd(klines))
    kdj_last = {k: v[-1] for k, v in kdj(klines).items()}
    rsi24 = rsi(klines, (24,))[24][-1]

    parts = {
        "ma_align": _ma_align_score(ma_dict),
        "price_vs_ma": _price_vs_ma_score(close, ma_dict),
        "macd": _macd_score(macd_dict),
        "kdj": _kdj_score(kdj_last),
        "rsi": _rsi_healthy_score(rsi24),
    }
    score = sum(parts[k] * TECH_WEIGHTS[k] for k in parts)
    return {
        "score": round(score, 2),
        "bullish": score >= 60,
        **parts,
    }


def _ma_last(ma_dict):
    """取各周期 MA 的最新一个有效值。"""
    out = {}
    for p, vals in ma_dict.items():
        last = next((v for v in reversed(vals) if v is not None), None)
        out[p] = last
    return out


def _macd_last(macd_dict):
    out = {}
    for key, vals in macd_dict.items():
        out[key] = next((v for v in reversed(vals) if v is not None), None)
    return out


if __name__ == "__main__":
    from kline import fetch_kline
    k = fetch_kline("sh600519", count=120)
    s = summarize(k)
    for key, val in s.items():
        if isinstance(val, float):
            print(f"{key:>14s}: {val:.2f}")
        else:
            print(f"{key:>14s}: {val}")
